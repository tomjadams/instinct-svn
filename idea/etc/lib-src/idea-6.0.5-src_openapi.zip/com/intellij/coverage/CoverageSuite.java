package com.intellij.coverage;

import org.jetbrains.annotations.NotNull;

/**
 * @author ven
 */
public abstract class CoverageSuite {
  protected CoverageSuite() {}

  @NotNull
  public abstract String getCoverageDataFileName();

  @NotNull
  public abstract String[] getFilteredPackageNames();

  @NotNull
  public abstract String[] getFilteredClassNames();

  public abstract long getLastCoverageTimeStamp();

  public abstract String getPresentableName();
}
