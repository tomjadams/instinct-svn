/*
 * Copyright (c) 2000-2004 by JetBrains s.r.o. All Rights Reserved.
 * Use is subject to license terms.
 */
package com.intellij.coverage;

import java.io.File;

/**
 * @author Eugene Zhuravlev
 *         Date: Jul 8, 2006
 */
public final class DefaultCoverageFileProvider implements CoverageFileProvider{
  private final File myFile;

  public DefaultCoverageFileProvider(String path) {
    this(new File(path));
  }

  public DefaultCoverageFileProvider(File file) {
    myFile = file;
  }

  public String getCoverageDataFilePath() {
    return myFile.getPath();
  }

  public boolean ensureFileExists() {
    return myFile.exists();
  }
}
