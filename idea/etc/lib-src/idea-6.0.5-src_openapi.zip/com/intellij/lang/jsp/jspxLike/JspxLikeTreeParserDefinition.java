package com.intellij.lang.jsp.jspxLike;

import com.intellij.lang.ParserDefinition;
import com.intellij.openapi.application.ApplicationManager;
import com.intellij.openapi.components.ApplicationComponent;
import org.jetbrains.annotations.NonNls;
import org.jetbrains.annotations.NotNull;

public abstract class JspxLikeTreeParserDefinition implements ParserDefinition, ApplicationComponent {
  public static JspxLikeTreeParserDefinition getInstance() {
    return ApplicationManager.getApplication().getComponent(JspxLikeTreeParserDefinition.class);
  }

  @NonNls
  @NotNull
  public String getComponentName() {
    return "JspxLikeTree parser definition";
  }

  public void initComponent() {
  }

  public void disposeComponent() {
  }
}
