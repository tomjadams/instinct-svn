/*
 * Copyright (c) 2000-2006 JetBrains s.r.o. All Rights Reserved.
 */

package com.intellij.ide.util.projectWizard;

import com.intellij.ide.wizard.CommitStepException;
import com.intellij.openapi.ui.Messages;
import com.intellij.CommonBundle;

import javax.swing.*;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NotNull;

/**
 * @author nik
 */
public abstract class AddSupportStep<T extends AddSupportContext> extends ModuleWizardStep {

  @NotNull
  protected final T myContext;
  @Nullable
  private final Icon myIcon;

  protected AddSupportStep(final T context, final Icon icon) {
    myIcon = icon;
    myContext = context;
  }

  protected AddSupportStep(final T context) {
    this(context, null);
  }

  public final void _init() {
    if (!myContext.isInsideAddModuleWizard()) {
      updateStep();
    }
  }

  public final void _commit(boolean finishChosen) throws CommitStepException {
    if (!myContext.isInsideAddModuleWizard()) {
      updateDataModel();
      if (finishChosen) {
        checkValidity();
      }
    }
  }

  public final boolean validate() {
    try {
      checkValidity();
      return true;
    }
    catch (CommitStepException e) {
      Messages.showErrorDialog(e.getMessage(), CommonBundle.getErrorTitle());
      return false;
    }
  }

  protected void checkValidity() throws CommitStepException {
  }

  @Nullable
  public final Icon getIcon() {
    return myIcon;
  }

  public boolean isStepVisible() {
    return myContext.isAddSupport();
  }
}
