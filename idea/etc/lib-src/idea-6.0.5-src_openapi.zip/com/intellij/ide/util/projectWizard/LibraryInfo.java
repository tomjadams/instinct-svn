package com.intellij.ide.util.projectWizard;

import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.NonNls;

/**
 * @author Dmitry Avdeev
 */
public interface LibraryInfo {

  LibraryInfo[] EMPTY_ARRAY = new LibraryInfo[0];
  
  @Nullable @NonNls
  String getDownloadingUrl();

  @NonNls
  String getExpectedJarName();

  String[] getRequiredClasses();

  String getPresentableUrl();

  @Nullable @NonNls
  String getVersion();

}
