/*
 * Copyright 2000-2005 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.intellij.openapi.extensions.impl;

import com.thoughtworks.xstream.converters.reflection.ReflectionProvider;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;

/**
 * @author Alexander Kireyev
 */
public class PropertyReflectionProvider implements ReflectionProvider {
  public Object newInstance(Class aClass) {
    try {
      return aClass.newInstance();
    }
    catch (InstantiationException e) {
      throw new RuntimeException(e);
    }
    catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }

  public void visitSerializableFields(Object object, Visitor visitor) {
    try {
      BeanInfo beanInfo = Introspector.getBeanInfo(object.getClass());
      PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
      for (PropertyDescriptor descriptor : propertyDescriptors) {
        if (descriptor.getWriteMethod() != null && descriptor.getReadMethod() != null) {
          visitor.visit(descriptor.getName(), descriptor.getPropertyType(), object.getClass(), descriptor.getReadMethod().
            invoke(object, ((Object[])null)));
        }
      }
    }
    catch (IntrospectionException e) {
      throw new RuntimeException(e);
    }
    catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
    catch (InvocationTargetException e) {
      throw new RuntimeException(e);
    }
  }

  public void writeField(Object object, String name, Object value, Class definedIn) {
    try {
      findDescriptor(name, object.getClass()).getWriteMethod().invoke(object, value);
    }
    catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
    catch (InvocationTargetException e) {
      throw new RuntimeException(e);
    }
  }

  public Class getFieldType(Object object, String name, Class definedIn) {
    PropertyDescriptor descriptor = findDescriptor(name, object.getClass());
    if (descriptor == null) throw new IllegalArgumentException("Cannot find property " + name + " in class " + object.getClass().getName());
    return descriptor.getPropertyType();
  }

  public boolean fieldDefinedInClass(String name, Class aClass) {
    return findDescriptor(name, aClass) != null;
  }

  private static PropertyDescriptor findDescriptor(String name, Class aClass) {
    PropertyDescriptor[] descriptors;
    try {
      descriptors = Introspector.getBeanInfo(aClass).getPropertyDescriptors();
    }
    catch (IntrospectionException e) {
      throw new RuntimeException(e);
    }
    for (PropertyDescriptor descriptor : descriptors) {
      if (name.equals(descriptor.getName())) return descriptor;
    }
    return null;
  }
}
