// $Id: Generator.java 12 2006-11-07 17:51:44Z mgm7734 $
package net.sf.jdummy.generator;

/**
 * Strategy for generating values of a given type.
 * @author mmendel
 *
 * @param <T> type for which values are generated
 */
public interface Generator {
    Object generateValue(String baseName);
}