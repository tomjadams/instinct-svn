// $Id: DefaultGeneratorBuilder.java 12 2006-11-07 17:51:44Z mgm7734 $
package net.sf.jdummy.generator;

import java.math.BigDecimal;
import java.math.BigInteger;


/**
 * Adds default generators to DummyValueFactory.  Includes all primitives, primitive wrappers
 * and String.
 * @author mgm
 */
class DefaultGeneratorBuilder {
    private final DummyValueFactory owner;

    DefaultGeneratorBuilder(DummyValueFactory owner) {
        this.owner = owner;
        initGenerators();
    }

    void initGenerators() {
        owner.setGenerator(String.class, new Generator() {
            public Object generateValue(String baseName) {
                return owner.nextName(baseName==null ? "anon" : baseName);
            }});
        
        addGeneratorPair(
                double.class, Double.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return new Double(owner.nextDouble());
                    }});       
        addGeneratorPair(
                float.class, Float.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return new Float(owner.nextFloat());
                    }});       
        addGeneratorPair(
                long.class, Long.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return new Long(owner.nextLong());
                    }});       
        addGeneratorPair(
                int.class, Integer.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return new Integer(owner.nextInt());
                    }});       
        addGeneratorPair(
                char.class, Character.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return new Character((char) 
                                rnd(Character.MAX_VALUE, Character.MIN_VALUE));
                    }});       
        addGeneratorPair(
                short.class, Short.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return new Short((short) 
                                rnd(Short.MAX_VALUE, Short.MIN_VALUE));
                    }});       
        addGeneratorPair(
                byte.class, Byte.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return new Byte((byte) 
                                rnd(Byte.MAX_VALUE, Byte.MIN_VALUE));
                    }});       
        addGeneratorPair(
                boolean.class, Boolean.class, new Generator() {
                    public Object generateValue(String baseName) {
                        return Boolean.valueOf(owner.nextBoolean());
                    }});       
        
        owner.setGenerator(BigDecimal.class, new Generator() {
            public Object generateValue(String label) { 
                return new BigDecimal(owner.nextDouble());
            }});
        
        owner.setGenerator(BigInteger.class, new Generator() {
            public Object generateValue(String baseName) {
                return new BigInteger(32, owner);
            }});       
    }   
    
    public int rnd(int max, int min) {
        return owner.nextInt(max - min + 1) + min;
    }

    public   void addGeneratorPair(
            Class primType, Class wrapperType, Generator gen) {
        owner.setGenerator(primType, gen);
        owner.setGenerator(wrapperType, gen);
    }

}
