// $Id: Mockery.java 12 2006-11-07 17:51:44Z mgm7734 $ 
package net.sf.jdummy;

import java.util.HashMap;
import java.util.Iterator;

import org.jmock.Mock;
import org.jmock.cglib.CGLIBCoreMock;
import org.jmock.core.AbstractDynamicMock;
import org.jmock.core.CoreMock;
import org.jmock.core.DynamicMock;
import org.jmock.core.Verifiable;

/**
 * Factory for all Mock objects.  This class will be replaced when jMock-2 is released. 
 * @author <a href="mailto:mgm7734@yahoo.com>Mark G> Mendel</a>
 */
public class Mockery {
    private HashMap proxy2Mock = new HashMap();
    
    public  Mockery() {
    }
    
    public Object mock(Class type) {
        return mock(type, CoreMock.mockNameFromClass(type));
    }
    
    public Object mock(Class type, String roleName) {
        return registerProxy(newCoreMock(type, roleName));
    }
    
    private DynamicMock newCoreMock(Class type, String roleName) {
        AbstractDynamicMock coreMock;
        if (type.isInterface())
            coreMock = new CoreMock(type, roleName);
        else
            coreMock = new CGLIBCoreMock(type, roleName);
        return coreMock;
    }
    
    public Mock asMock(Object o) {
        DynamicMock dynamicMock = asDynamicMock(o);
        if (dynamicMock instanceof Mock) {
            return (Mock) dynamicMock;
        }
        Mock result = new Mock(dynamicMock);
        registerProxy(result);
        return result;
    }
    
    public DynamicMock asDynamicMock(Object o) {
        DynamicMock dynamicMock = (DynamicMock) proxy2Mock.get(o);
        if (dynamicMock == null) {
            throw new IllegalArgumentException("not a mocked object:" + o);
        }
        return dynamicMock;
    }
    protected Object registerProxy(DynamicMock dynamicMock) {
        Object proxy = dynamicMock.proxy();
        proxy2Mock.put(proxy, dynamicMock);
        return proxy;
    }
    public void verify() {
        for (Iterator iter = proxy2Mock.values().iterator(); iter.hasNext();) {
            Verifiable v = (Verifiable) iter.next();
            v.verify();
        }
    }
}
