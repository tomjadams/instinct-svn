// $Id: DummyValueGeneratingStubFactory.java 12 2006-11-07 17:51:44Z mgm7734 $
package net.sf.jdummy.generator;

import java.util.HashMap;

import org.jmock.core.Invocation;
import org.jmock.core.Stub;

/**
 * Manaages stubs that generate consistent dummy results for invocations.  Identical
 * invocations (same object, same arguments) will return the same result.
 * 
 * @author <a href="mailto:mgm7734@yahoo.com>Mark G> Mendel</a>
 */
class DummyValueGeneratingStubFactory {
	
	private static final String METHOD_SEPARATOR = ".";
	protected final DummyValueFactory valueFactory;
	protected HashMap resultCache = new HashMap();
	
	/**
	 * @param valueFactory
	 */
	public DummyValueGeneratingStubFactory(DummyValueFactory valueFactory) {
		this.valueFactory = valueFactory;
	}
	
	public DummyValueGeneratingStub createStub() {
		return new DummyValueGeneratingStub();
	}
	
	protected Object handle(Invocation invocation) throws Throwable {
		if (void.class == invocation.invokedMethod.getReturnType()) {
			return null;
		}
		Object result = resultCache.get(invocation);
		if (result == null) {
			result = makeResult(invocation);
			resultCache.put(invocation, result);
		}
		return result;
	}
	
	protected Object makeResult(Invocation invocation) {
		Object result;
		Class returnType = invocation.invokedMethod.getReturnType();
		if (returnType == String.class) {
			result = makeResultName(invocation);
		}
		else {
			result = valueFactory.dummy(returnType,  makeResultName(invocation));
		}
		return result;
	}
	
	protected String makeResultName(Invocation invocation) {
		StringBuffer result = new StringBuffer();
		result.append(invocation.invokedObject.toString());
		result.append(METHOD_SEPARATOR);
		String methodName =  invocation.invokedMethod.getName();
		if (methodName.startsWith("get") && methodName.length() > 3) {
			result.append(methodName.substring(3, 4).toLowerCase());
			result.append(methodName.substring(4));
		}
		else {
			result.append(methodName);
		}
        if (invocation.parameterValues.isEmpty()) {
            return result.toString();
        } else {
            return valueFactory.nextName(result.toString());
        }
	}

	private class DummyValueGeneratingStub implements Stub {		
		public Object invoke(Invocation invocation) throws Throwable {
			return handle(invocation);
		}			
		public StringBuffer describeTo(StringBuffer buf) {
			buf.append("returns dummy values");
			return buf;
		}
	}
}
