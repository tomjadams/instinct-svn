// $Id: DummyValueFactory.java 12 2006-11-07 17:51:44Z mgm7734 $
package net.sf.jdummy.generator;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.HashMap;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

import net.sf.jdummy.Mockery;

import org.jmock.Mock;
import org.jmock.core.DynamicMock;
import org.jmock.core.Formatting;
import org.jmock.core.VerifyingTestCase;

/**
 * Factory for generating dummy data.   To genearte a value for type T, will use
 * the Generator set for T if one exists (see {@link #setGenerator(Class, Generator)}
 * and {@link DefaultGeneratorBuilder}. 
 * <p>
 * If no explicit Generator exists for T,
 * the factory will create a 'dummy', i.e., create a Mock of T, give it a dummy value 
 * generating default stub, and return the proxy.
 * 
 * <p>DummyValueFactory inherits from Random. Tests that use random values should use
 * a single instance of DummyValueFactory to generate all values.
 * Unlike Random, the factory's seed is 0L by default.  This makes tests using the factory 
 * repeatable: the same sequence value-creation requests will yield the same values. 
 * 
 * @see net.sf.jdummy.generator.DummyValueGeneratingStubFactory
 * @author <a href='mailto:mgm7734@yahoo.com'> Mark G. Mendel </a> 
 */
public class DummyValueFactory extends Random {
    private static final long serialVersionUID = 1L;
    private final Logger logger = Logger.getLogger(this.getClass().getName());
    private final Mockery mockery;  
    private HashMap generatorMap =  new HashMap();
    private HashMap nameCounterMap = new HashMap();
    private DummyValueGeneratingStubFactory stubFactory =  
        new DummyValueGeneratingStubFactory(this);
    
    /** @deprecated */
    public DummyValueFactory(VerifyingTestCase verifier) {
        this(new CompatibleMockery(verifier));
      }
    
    public DummyValueFactory(Mockery mockery) {
    	super(0L);
    	this.mockery = mockery;
    	new DefaultGeneratorBuilder(this);
    }

    public Object dummy(Class type) {
        String makeName = makeInstanceName(
                type.isArray() ? type.getComponentType() : type);
        return dummy(type, makeName);
    }

    public Object dummy(Class type, String name) {
        Object result;
    	Generator generator = (Generator) generatorMap.get(type);
    	if (generator != null) {
    		result = generator.generateValue(name);
    	}
    	else if (type.isArray()) {
    		result = makeDummyArray(type, name);
    	}
    	else if (Collection.class.isAssignableFrom(type)) {
    		throw new IllegalArgumentException(
    		        name + "("+ type.getName() +"): cannot build dummy Collections");
    	}
    	else {
    		result = newMockWithValueGeneratingStub(type, name);
    	}
    	if (logger.isLoggable(Level.FINE)) {    		
    		logger.fine("dummy: " + type + " " + name + " = " + result);
    	}
    	return result;
    }

    public Mock mockForProxy(Object dummy) {
       return mockery.asMock(dummy);        
    }
    
    protected DynamicMock dynamicMockForProxy(Object dummy) {
    	return mockery.asDynamicMock(dummy);
    }

    public  void setGenerator(Class type, Generator generator) {
        generatorMap.put(type, generator);
    }
    
    public  Generator getGenerator(Class type) {
        return (Generator) generatorMap.get(type);
    }

    protected  Object makeDummyArray(Class arrayType, String arrayName) {
        int size = 1 + this.nextInt(3);
        Class componentType = arrayType.getComponentType();
        Object result = Array.newInstance(componentType, size);
        StringBuffer memberName = new StringBuffer();
        if (arrayName == null ) {
            arrayName = baseName(componentType);
        }  
        memberName.append(arrayName);
        memberName.append(":");
        int baseLength = memberName.length();
        for (int i = 0; i < size; i++) {
            memberName.setLength(baseLength);
            memberName.append(i);
            Array.set(result, i, dummy(componentType, memberName.toString()));
        }
        return result;
    }
    
    public  Object newMockWithValueGeneratingStub(Class type) {
    	return newMockWithValueGeneratingStub(type, makeInstanceName(type));
    }
    
    public  Object newMockWithValueGeneratingStub(Class type, String name) {
        DynamicMock mock;
        try {
            Object proxy = mockery.mock(type, name);
			mock = mockery.asDynamicMock(proxy);
			mock.setDefaultStub(stubFactory.createStub());
			return proxy;
        } catch (Exception ex) {
            throw new IllegalArgumentException(
                    type.getName() + " cannot be mocked; no default constructor? " + ex);
        }
    }

    private  String makeInstanceName(Class type) {
    	return nextName(baseName(type));
    }

    private String baseName(Class type) {
        return "dummy" + Formatting.classShortName(type);
    }
    
    /**
     * Returns the next unique name string of the form
     * <i>baseName</i>-1, <i>baseName</i>-2, ...  
     */
    public String OLD_nextName(String baseName) {
        Integer counter = (Integer) nameCounterMap.get(baseName);
        int val = (counter == null ? 1 : counter.intValue());
        nameCounterMap.put(baseName, new Integer(val + 1));
        return baseName + "-" + val;
    }
    
    /**
     * Returns the next unique name string of the form
     * <i>baseName</i>, <i>baseName</i>-2, ...  
     */
    public String nextName(String baseName) {
    	Integer counter = (Integer) nameCounterMap.get(baseName);
    	if (counter == null) {
        	nameCounterMap.put(baseName, new Integer(2));
    		return baseName;
    	}
    	else {
	    	nameCounterMap.put(baseName, new Integer(counter.intValue() + 1));
	    	return baseName + "-" + counter;
    	}
    }
    
    static class CompatibleMockery extends Mockery {
    	private VerifyingTestCase delegateVerifier;
    	public CompatibleMockery(VerifyingTestCase delegateVerifier) {
    		this.delegateVerifier = delegateVerifier;		
    	}
    	public Object mock(Class type, String roleName) {
    		Object proxy = super.mock(type, roleName);
    		if (delegateVerifier!= null) {
    			delegateVerifier.registerToVerify(asDynamicMock(proxy));
    		}
    		return proxy;
    	}	
    }
 }
