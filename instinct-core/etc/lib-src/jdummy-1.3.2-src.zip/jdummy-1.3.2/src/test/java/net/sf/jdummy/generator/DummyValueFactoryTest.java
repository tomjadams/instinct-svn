// Copyright 2005 Mark G. Mendel.
// All rights reserved until I can figure out which copyleft to use. 
package net.sf.jdummy.generator;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Collection;
import java.util.Vector;

import net.sf.jdummy.Mockery;
import net.sf.jdummy.generator.DummyValueFactory;
import net.sf.jdummy.generator.Generator;

import org.jmock.Mock;
import org.jmock.cglib.MockObjectTestCase;
import org.jmock.core.Verifiable;
import org.jmock.core.VerifyingTestCase;

/**
  * @author <a href='mailto:mgm7734@yahoo.com'> Mark G. Mendel </a> 
  */
public class DummyValueFactoryTest extends MockObjectTestCase {
    
    DummyValueFactory valueFactory = new DummyValueFactory(new Mockery());
    
    interface DummyType extends ResultSet {}
    DummyType dummy = (DummyType) dummy(DummyType.class, "dumbo");
    Mock mock = valueFactory.mockForProxy(dummy);
    
    public void testCreateBasicDummy() throws Exception {
        assertNotNull(dummy);          
        assertNotNull(mock);
        assertEquals("dumbo", dummy.toString());
        
        mock.stubs().method("getObject").will(returnValue(this));       
        assertSame(this, dummy.getObject(null));
    }
    
    public void testCustomGenerator() throws Exception {
         final Object[] objs = new Object[1];
        
        Generator objectGenerator = 
            new Generator() {
                public Object generateValue(String label) {
                    return objs[0];
                }};
        valueFactory.setGenerator(Object.class, objectGenerator);        
        
        assertSame(objectGenerator, valueFactory.getGenerator(Object.class));
        
        objs[0] = new Object();
        
        assertSame(objs[0], dummy(Object.class));
    }
    
    public void testDummyValueGeneratingStub() throws Exception {
        final int[] objs = new int[1];
        
        valueFactory.setGenerator(int.class, new Generator() {
            public Object generateValue(String label) {
                return new Integer(objs[0]);
            }});  
        objs[0] = 1324;
        assertEquals(objs[0], dummy.getInt(1));
    }
    
    public void testDummyMocksAreRegisteredWithVerifier() throws Exception {
        final Verifiable[] target = {null};
        VerifyingTestCase verifier = new VerifyingTestCase() {
            public void registerToVerify(Verifiable v) {
               target[0] = v;
            }
            public void unregisterToVerify(Verifiable v) {
                target[0] = null;
            }
        };
        DummyValueFactory dvf = new DummyValueFactory(verifier);
        
        DummyType dummy = (DummyType) dvf.dummy(DummyType.class);
        assertSame("explicitly created dummy objects must be registered",
                target[0], dvf.dynamicMockForProxy(dummy));
        
        ResultSetMetaData dummyMetaData = dummy.getMetaData();
        assertSame("auto-generated dummy objects must be registered",
                target[0], dvf.dynamicMockForProxy(dummyMetaData));
    }
    
    public void testRandomSeedDefaultIsZero() {
        Integer pseudoRand1 = (Integer) valueFactory.dummy(Integer.class);
        Integer pseudoRand2 = (Integer) valueFactory.dummy(Integer.class);
        DummyValueFactory seededFactory = new DummyValueFactory(new Mockery());
        assertFalse("", pseudoRand1.equals(pseudoRand2));
        
        seededFactory.setSeed(0L);
        assertEquals("pseudo-random values must be function of seed",        
                pseudoRand1, seededFactory.dummy(Integer.class));
        assertEquals("pseudo-random values must be function of seed",        
                pseudoRand2, seededFactory.dummy(Integer.class));
 
        seededFactory.setSeed(0L);
        assertEquals("pseudo-random values must be function of seed",        
                pseudoRand1, seededFactory.dummy(Integer.class));        
    }
    
    public interface TestTree {
        TestTree getChild(int n);
        TestTree someOtherMethod(String someArg);
    }
    public void testDummyNaming() throws Exception {
        assertEquals(dummy.toString()+".metaData", 
                dummy.getMetaData().toString());
        assertEquals("dummyTestTree", dummy(TestTree.class).toString());
        TestTree root = (TestTree) dummy(TestTree.class, "root");
        assertEquals("root.child", root.getChild(55).toString());
        assertEquals("root.child-2", root.getChild(58).toString());
        assertEquals("root.child.someOtherMethod", 
                root.getChild(55).someOtherMethod("a").toString());
        assertEquals("root.child.someOtherMethod", 
                root.getChild(55).someOtherMethod("a").toString());
        assertEquals("root.child.someOtherMethod-2", 
                root.getChild(55).someOtherMethod("b").toString());
    }
    
    interface ArrayMaker {
        TestTree[] getTrees(int n);
        float[] getFloaties(int n);
    }
    public void testArrayGeneration() { 
        ArrayMaker arrayMaker = (ArrayMaker) dummy(ArrayMaker.class, "am");
        int minSize = 100;
        int maxSize = 0;
        for (int n = 0; n < 10; n++) {
            assertNotNull("must generate arrays", arrayMaker.getTrees(n));
            assertSame("must cache results",
                    arrayMaker.getTrees(n),  arrayMaker.getTrees(n));
            assertTrue("must generate arrays of size > 0",
                    arrayMaker.getTrees(n).length > 0);
            for (int i = 0; i < arrayMaker.getTrees(n).length; i++) {
                assertNotNull("must generate array elements",
                        arrayMaker.getTrees(n)[i]);
                assertEquals("am.trees" + (n > 0 ? "-" + (n+1) : "" ) + ":" + i, 
                        arrayMaker.getTrees(n)[i].toString());
            }
            minSize = Math.min(minSize,arrayMaker.getTrees(n).length);
            maxSize = Math.max(maxSize, arrayMaker.getTrees(n).length);
        }
        assertTrue(minSize < maxSize);
        assertTrue(0 < minSize);
        
        valueFactory.setGenerator(int.class, new Generator() {
            public Object generateValue(String baseName) {
                return new Integer(valueFactory.nextInt());
            }});
        int[] ia = (int[]) dummy(int[].class);
        assertNotNull(ia);
        
        TestTree[] trees = (TestTree[]) dummy(TestTree[].class);
        assertEquals("dummyTestTree:0", trees[0].toString());
    }
    
    public void testPrimitiveArrayGeneration() { 
        ArrayMaker arrayMaker = (ArrayMaker) dummy(ArrayMaker.class, "am");
        int minSize = 100;
        int maxSize = 0;
        for (int n = 0; n < 10; n++) {
            assertNotNull("must generate arrays", arrayMaker.getFloaties(n));
            assertSame("must cache results",
                    arrayMaker.getFloaties(n),  arrayMaker.getFloaties(n));
            assertTrue("must generate arrays of size > 0",
                    arrayMaker.getFloaties(n).length > 0);
            
            for (int i = 0; i < arrayMaker.getFloaties(n).length; i++) {
                assertTrue("must generate nonzero array elements",
                        arrayMaker.getFloaties(n)[i] != 0F);
            }
            minSize = Math.min(minSize,arrayMaker.getFloaties(n).length);
            maxSize = Math.max(maxSize, arrayMaker.getFloaties(n).length);
        }
        assertTrue(minSize < maxSize);
        assertTrue(0 < minSize);
        
        valueFactory.setGenerator(int.class, new Generator() {
            public Object generateValue(String baseName) {
                return new Integer(valueFactory.nextInt());
            }});
        int[] ia = (int[]) dummy(int[].class);
        assertNotNull(ia);        
   }
    
    public void testRefusesToMockCollections() {
        testUnmockableHelper(Collection.class);
        testUnmockableHelper(Vector.class);
     }
    
    static final class AFinalClass {}
    static class ClassWithNoDefaultConstructor { 
        public ClassWithNoDefaultConstructor(Object o) {}}
    public void testUnmockablesFailWithAMeaningfulMessage() {
        testUnmockableHelper(AFinalClass.class);
        testUnmockableHelper(ClassWithNoDefaultConstructor.class);
      }
    private void testUnmockableHelper(Class clazz) {
        try {
            dummy(clazz);
            fail("it should not be possible to mock " + clazz);
        } catch (IllegalArgumentException ex) {
            // OK
            assertTrue("exception must mention the unmockable class",
                    ex.getMessage().indexOf(clazz.getName()) != -1);
        }
    }
    
    public void testStringGeneration() throws Exception {
        assertEquals("x", dummy(String.class, "x"));
        assertEquals("x-2", dummy(String.class, "x"));
        assertEquals("dumbo.string", dummy.getString(1));
        assertEquals("dumbo.string-2", dummy.getString(2));
    }
    
    public void testHasGeneratorsForStandardTypes() {
        testHasGen(String.class);
        
        testHasGenPair(double.class, Double.class);
        testHasGenPair(float.class, Float.class);
        testHasGenPair(long.class, Long.class);
        testHasGenPair(int.class, Integer.class);
        testHasGenPair(short.class, Short.class);
        testHasGenPair(byte.class, Byte.class);
        testHasGenPair(boolean.class, Boolean.class);
        
        testHasGen(BigInteger.class);
        testHasGen(BigDecimal.class);
    }
    
    private  void testHasGenPair(Class dataType, Class wrapperType) {
        testHasGen(dataType);
        testHasGen(wrapperType);
     }
    private  void testHasGen(Class type) {
        assertNotNull("must have generator for " + type, valueFactory.getGenerator(type));      
    }
    
    private  Object dummy(Class type) {
        return valueFactory.dummy(type);
    }
    private  Object dummy(Class type, String name) {
        return valueFactory.dummy(type, name);
    }
 }
