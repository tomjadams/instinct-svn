package net.sf.jdummy;

import junit.framework.TestCase;

/**
 * 
 * @author <a href="mailto:mgm7734@yahoo.com>Mark G> Mendel</a>
 */
public class MockeryTest extends TestCase {
    public void testAsMockFailsForNonMocks() {
        Mockery mockery = new Mockery();
        try {
            mockery.asMock(this);
            fail("asMock() must throw exception for non-mocks");
        }
        catch (IllegalArgumentException ex) {
            // OK
        }
    }
}
