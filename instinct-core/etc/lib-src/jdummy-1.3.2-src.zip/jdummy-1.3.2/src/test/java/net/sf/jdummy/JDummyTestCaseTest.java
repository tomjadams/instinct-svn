// Copyright 2005 Mark G. Mendel.
// All rights reserved until I can figure out which copyleft to use. 

package net.sf.jdummy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

import junit.framework.AssertionFailedError;
import junit.framework.Test;
import junit.framework.TestResult;
import junit.framework.TestSuite;

import org.jmock.core.DynamicMockError;


/**
 * @author mgm
 *
 */
public class JDummyTestCaseTest extends JDummyTestCase {
    
    static class DummyClass { 
        public String oneArgMethod(String p) {return p + "Z";}
        public String noArgMethod() {return "noArgMethResult";}
        public DummyClass dummyValuedMethod(DummyClass result) {
            return result;
        }
    }

    DummyClass dummy = (DummyClass) mimicWithDummyValues(DummyClass.class);
    
    public void testSimpleMimc() {
    	DummyClass d1 = (DummyClass) mimic(DummyClass.class, "name of mock");
    	
    	assertNotNull(d1);
    	assertEquals( "name of mock", d1.toString());
    	
    	precondition(d1).method("noArgMethod").will(returnValue(this.toString()));
    	assertEquals(this.toString(), d1.noArgMethod());
    	
    	try {
    		d1.oneArgMethod("");
    		fail("expected exception");
    	} 
    	catch (DynamicMockError ex) {
    		// OK
    	}
    	
    	assertEquals("mockDummyClass", mimic(DummyClass.class).toString());
    	
    }
    
    public void testDifferentInvocationsYieldDifferentStringResults() {
        DummyClass d1 = (DummyClass) mimicWithDummyValues(DummyClass.class, "d1");
        DummyClass d2 = (DummyClass) mimicWithDummyValues(DummyClass.class, "d2");
        
        assertFalse("invocations on different dummies must yield differnt results",
                d1.oneArgMethod("").equals(d2.oneArgMethod("")));
        assertFalse("invocations with different args must yield differnt results",
                d1.oneArgMethod("a").equals(d1.oneArgMethod("b")));
    }
    
    public void testStringResultsHaveMeaningfulSuffixes() {
        assertEquals("dummyDummyClass.oneArgMethod", dummy.oneArgMethod("a"));
        assertEquals("dummyDummyClass.oneArgMethod", dummy.oneArgMethod("a"));
        assertEquals("dummyDummyClass.oneArgMethod-2", dummy.oneArgMethod("b"));
        
        assertMatches("string valued methods with args must have numeric suffix", 
                ".*oneArgMethod-\\d+", 
                dummy.oneArgMethod("2"));
        assertMatches("string valued methods without args must end with meth name",
                ".*noArgMethod",
                dummy.noArgMethod());
     }

    private void assertMatches(String msg, String pattern, String result) {
         assertTrue(msg,
                result.matches(pattern));
    }
    
    public void testProvidesAliases() {
        
        precondition(dummy).method("toString").will(returnValue("X")); 
        
        assertBehavior(dummy).expects(atLeastOnce())
            .method("oneArgMethod").with(eq("k")).will(returnValue("Got it!"));
        
        assertEquals("X", dummy.toString());
        assertEquals("Got it!", dummy.oneArgMethod("k"));
      }
    
    public void testWillPickOne() {
        final String[] choices = {"apples", "oranges", "plan B"};
        
        assertBehavior(dummy).expects(once())
                .method("oneArgMethod").with(eq("1")).will(returnOneOf(choices));
        assertBehavior(dummy).expects(once())
                .method("oneArgMethod").with(eq("2")).will(returnOneOf(Arrays.asList(choices)))
                .id("2");
        assertBehavior(dummy).expects(never()).method("oneArgMethod").after("2");
        
        assertNotNull(dummy.oneArgMethod("1"));
        assertNotNull(dummy.oneArgMethod("2"));
        try {
            assertNotNull(dummy.oneArgMethod("3"));
            fail("should not allow 3rd invocation");
        } catch(AssertionFailedError ex) {
            // OK
        }
    }
    
    public void testFillWithDummiesWithObjects() {
        DummyClass[] dummies = (DummyClass[]) fillWithDummies(new DummyClass[3]);
        for (int i = 0 ; i < dummies.length ; ++i)
            assertNotNull(dummies[i]);
        
        ArrayList dummyColl = new ArrayList();
        assertSame(dummyColl, fillWithDummies(dummyColl, DummyClass.class, 3));
        assertEquals(3, dummyColl.size());
        for (Iterator itr = dummyColl.iterator(); itr.hasNext();) {
            Object d = (DummyClass) itr.next();
            assertTrue(d instanceof DummyClass);
            assertNotNull(d);
        }
     }
    
    public void testFillWithDummiesWithPrimitives() {
        float[] floaties = (float[]) fillWithDummies(new float[3]);
        for (int i = 1 ; i < floaties.length ; ++i) {
            assertTrue("must generate random values",
                    floaties[i] != floaties[0]);
        }
    }
    
    public void testFillWithDummiesWithFunnyCasting() {
        DummyClass[] dummyClasses = new DummyClass[3];

        assertSame(dummyClasses, fillWithDummies((Object) dummyClasses));
        
        for (int i = 0 ; i < dummyClasses.length ; ++i) {
            assertNotNull(dummyClasses[i]);
        }
    }
    
    
    public void testAssertNeverDummyWorksIfNotInvoked() {
        assertBehavior(dummy).expects(never());
    }
    public void testAssertNeverDummyWorksInvoked() {
        assertBehavior(dummy).expects(never());
        try {
            dummy.oneArgMethod("");
            fail("must fail if any method is invoked");
        } catch (AssertionFailedError e) {
            // OK
        }
    }    
    
    public void testGeneratedDummiesAreMocks() {
        DummyClass privateDummy = new DummyClass();     
        DummyClass generatedDummy = dummy.dummyValuedMethod(null);
        
        precondition(generatedDummy).method(
                "dummyValuedMethod").with(NULL).will(
                        returnValue(privateDummy)); 
       
        assertSame(privateDummy, generatedDummy.dummyValuedMethod(null));
    }
    
    public static void testVerifiesWhenDone() {
        Test suite = new TestSuite(TestVerifiesWhenDoneTestCase.class);
        TestResult result = new TestResult();
        suite.run(result);
        
        assertEquals(1, result.runCount());
        assertEquals(1, result.failureCount());
    }

    /** 
     * @author <a href='mailto:mmendel@digitalriver.com'> Mark G. Mendel </a> 
     */
    public static class TestVerifiesWhenDoneTestCase extends JDummyTestCase {
         public void testVerify() {
             Object r = mimic(Runnable.class);
            assertBehavior(r).expects(once()).method("run");
        }
     }
}
