package org.jmock.test.example.timedcache;

import java.util.Date;

public interface Clock {
    Date getCurrentTime();
}
