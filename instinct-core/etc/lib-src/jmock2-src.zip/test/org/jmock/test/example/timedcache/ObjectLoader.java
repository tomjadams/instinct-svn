package org.jmock.test.example.timedcache;

public interface ObjectLoader {
    Object load(Object key);
}
