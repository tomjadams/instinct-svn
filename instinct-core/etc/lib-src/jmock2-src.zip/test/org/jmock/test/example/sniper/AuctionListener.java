package org.jmock.test.example.sniper;

public interface AuctionListener {
    void bidAccepted(Lot item, Bid amount);
}
