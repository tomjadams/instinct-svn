package org.jmock.lib.nonstd;

import java.io.ObjectStreamClass;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.InvocationHandler;

import org.jmock.api.Imposteriser;
import org.jmock.api.Invocation;
import org.jmock.api.Invokable;

import sun.misc.Unsafe;

/**
 * This class lets you imposterise concrete classes with CGLIB 
 * <em>without</em> calling the constructors of the mocked class.
 *   
 * However, it uses undocumented, internal features of Sun's JVM.
 * It will not work on JVMs from other vendors. Sun may remove
 * the undocumented feature this class relies upon in any future
 * versions.
 * 
 * <strong>You have been warned!</strong>
 * 
 * @author npryce
 */
public class UnsafeHackConcreteClassImposteriser implements Imposteriser {
    private static final Unsafe unsafe = obtainAnUnsafeObjectByADodgyReflectionHack();
    
    public <T> T imposterise(final Invokable mockObject, Class<T> mockedType, Class<?>... ancilliaryTypes) {
        Class<?> proxyClass = createProxyClass(mockedType, ancilliaryTypes);
        return mockedType.cast(createProxy(proxyClass, mockObject));
	}
    
    private <T> Class<?> createProxyClass(Class<T> mockedType, Class<?>... ancilliaryTypes) {
        Enhancer enhancer = new Enhancer();
        enhancer.setClassLoader(mockedType.getClassLoader());
        if (mockedType.isInterface()) {
            enhancer.setSuperclass(Object.class);
            enhancer.setInterfaces(prepend(mockedType, ancilliaryTypes));
        }
        else {
            enhancer.setSuperclass(mockedType);
            enhancer.setInterfaces(ancilliaryTypes);
        }
        enhancer.setCallbackType(InvocationHandler.class);
        
        Class<?> proxyClass = enhancer.createClass();
        return proxyClass;
    }
	
    private Object createProxy(Class<?> proxyClass, final Invokable mockObject) {
        try {
            Object proxy = unsafe.allocateInstance(proxyClass);
            Field callbackField = proxyClass.getDeclaredField("CGLIB$CALLBACK_0");
            callbackField.setAccessible(true);
            callbackField.set(proxy, new InvocationHandler() {
                public Object invoke(Object receiver, Method method, Object[] args) throws Throwable {
                    return mockObject.invoke(new Invocation(receiver, method, args));
                }
            });
            return proxy;
        }
        catch (InstantiationException e) {
            throw new IllegalStateException("proxy class not instantiable", e);
        }
        catch (SecurityException e) {
            throw new IllegalStateException("cannot access private callback field", e);
        }
        catch (IllegalAccessException e) {
            throw new IllegalStateException("cannot access private callback field", e);
        }
        catch (NoSuchFieldException e) {
            throw new IllegalStateException("callback field does not exist", e);
        }
    }

    private Class<?>[] prepend(Class<?> first, Class<?>... rest) {
        Class<?>[] all = new Class<?>[rest.length+1];
        all[0] = first;
        System.arraycopy(rest, 0, all, 1, rest.length);
        return all;
    }
    
    static Unsafe obtainAnUnsafeObjectByADodgyReflectionHack() {
        try {
            Class<?> fieldReflectorClass = 
                Class.forName(ObjectStreamClass.class.getName() + "$FieldReflector");
            Field unsafeField = fieldReflectorClass.getDeclaredField("unsafe");
            unsafeField.setAccessible(true);
            
            return (Unsafe)unsafeField.get(null);
        }
        catch (ClassNotFoundException e) {
            throw new IllegalStateException("cannot load FieldReflector class", e);
        }
        catch (SecurityException e) {
            throw new IllegalStateException("cannot reflect on private field of FieldReflector", e);
        }
        catch (NoSuchFieldException e) {
            throw new IllegalStateException("cannot find 'unsafe' field of FieldReflector", e);
        }
        catch (IllegalAccessException e) {
            throw new IllegalStateException("field not accessible despite being made accessible", e);
        }
    }
}
