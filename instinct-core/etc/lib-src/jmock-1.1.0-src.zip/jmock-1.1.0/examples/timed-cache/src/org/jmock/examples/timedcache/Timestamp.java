/*  Copyright (c) 2000-2004 jMock.org
 */
package org.jmock.examples.timedcache;

/**
 * @author sfreeman
 *         <p/>
 *         To change the template for this generated type comment go to
 *         Window - Preferences - Java - Code Generation - Code and Comments
 */
public interface Timestamp
{
}
