/*  Copyright (c) 2000-2004 jMock.org
 */
package org.jmock.examples.timedcache;

public interface ObjectLoader
{

    Object load( Object theKey );
}
