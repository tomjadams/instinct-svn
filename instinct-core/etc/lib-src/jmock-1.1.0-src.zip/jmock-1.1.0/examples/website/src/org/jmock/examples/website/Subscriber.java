/*  Copyright (c) 2000-2004 jMock.org
 */
package org.jmock.examples.website;


interface Subscriber
{
    void receive( Message message );
}
