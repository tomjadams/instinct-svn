/*  Copyright (c) 2000-2004 jMock.org
 */
package org.jmock.examples.website;

public class Message
{

}
