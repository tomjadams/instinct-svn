/*  Copyright (c) 2000-2004 jMock.org
 */
package org.jmock.builder;

/**
 * @since 1.0
 */
public interface IdentityBuilder
{
    void id( String id );
}
