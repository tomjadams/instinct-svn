package fj;

/**
 * A transformation function of arity-2 from <code>A</code> and <code>B</code> to <code>C</code>.
 * This type can be represented using the Java 7 closure syntax.
 *
 * @version ${build.number}<br>
 *          <ul>
 *          <li>$LastChangedRevision: 10365 $</li>
 *          <li>$LastChangedDate: 2008-05-12 10:21:55 +1000 (Mon, 12 May 2008) $</li>
 *          </ul>
 */
public interface F2<A, B, C> {
  /**
   * Transform <code>A</code> and <code>B</code> to <code>C</code>.
   *
   * @param a The <code>A</code> to transform.
   * @param b The <code>B</code> to transform.
   * @return The result of the transformation.
   */
  C f(A a, B b);
}
