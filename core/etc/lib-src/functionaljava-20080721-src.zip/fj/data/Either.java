package fj.data;

import static fj.Bottom.error;
import fj.Effect;
import fj.F;
import static fj.Function.identity;
import static fj.P.p;
import fj.P1;
import fj.Unit;
import static fj.Unit.unit;
import static fj.data.Array.array;
import static fj.data.List.single;
import static fj.data.Option.some;

/**
 * The <code>Either</code> type represents a value of one of two possible types (a disjoint union).
 * The data constructors; <code>Left</code> and <code>Right</code> represent the two possible
 * values. The <code>Either</code> type is often used as an alternative to
 * <code>scala.Option</code> where <code>Left</code> represents failure (by convention) and
 * <code>Right</code> is akin to <code>Some</code>.
 * 
 * @version ${build.number}<br>
 *          <ul>
 *          <li>$LastChangedRevision: 10833 $</li>
 *          <li>$LastChangedDate: 2008-05-28 11:00:23 +1000 (Wed, 28 May 2008) $</li>
 *          </ul>
 */
public abstract class Either<A, B> {
  private Either() {
    
  }

  /**
   * Projects this either as a left.
   *
   * @return A left projection of this either.
   */
  public LeftProjection<A, B> left() {
    return new LeftProjection<A, B>(this);
  }

  /**
   * Projects this either as a right.
   *
   * @return A right projection of this either.
   */
  public RightProjection<A, B> right() {
    return new RightProjection<A, B>(this);
  }

  /**
   * Returns <code>true</code> if this either is a left, <code>false</code> otherwise.
   *
   * @return <code>true</code> if this either is a left, <code>false</code> otherwise.
   */
  public abstract boolean isLeft();

  /**
   * Returns <code>true</code> if this either is a right, <code>false</code> otherwise.
   *
   * @return <code>true</code> if this either is a right, <code>false</code> otherwise.
   */
  public abstract boolean isRight();

  /**
   * If this is a left, then return the left value in right, or vice versa.
   *
   * @return The value of this either swapped to the opposing side.
   */
  public Either<B, A> swap() {
    return isLeft() ? new Right<B, A>(((Left<A, B>)this).a) : new Left<B, A>(((Right<A, B>)this).b);
  }

  private static final class Left<A, B> extends Either<A, B> {
    private final A a;

    Left(final A a) {
      this.a = a;
    }

    public boolean isLeft() {
      return true;
    }

    public boolean isRight() {
      return false;
    }
  }

  private static final class Right<A, B> extends Either<A, B> {
    private final B b;

    Right(final B b) {
      this.b = b;
    }

    public boolean isLeft() {
      return false;
    }

    public boolean isRight() {
      return true;
    }
  }

  /**
   * A left projection of an either value.
   */
  public final class LeftProjection<A, B> {
    private final Either<A, B> e;

    private LeftProjection(final Either<A, B> e) {
      this.e = e;
    }

    /**
     * The either value underlying this projection.
     *
     * @return The either value underlying this projection.
     */
    public Either<A, B> either() {
      return e;
    }

    /**
     * Returns the value of this projection or fails with the given error message.
     *
     * @param err The error message to fail with.
     * @return The value of this projection
     */
    public A valueE(final P1<String> err) {
      if(e.isLeft())
        //noinspection CastToConcreteClass
        return ((Left<A, B>)e).a;
      else
        throw error(err._1());
    }

    /**
     * The value of this projection or fails with a specialised error message.
     *
     * @return The value of this projection.
     */
    public A value() {
      return valueE(p("left.value on Right"));
    }

    /**
     * The value of this projection or the given argument.
     *
     * @param a The value to return if this projection has no value.
     * @return The value of this projection or the given argument.
     */
    public A orValue(final P1<A> a) {
      return isLeft() ? value() : a._1();
    }

    /**
     * The value of this projection or the result of the given function on the opposing projection's
     * value.
     * 
     * @param f The function to execute if this projection has no value.
     * @return The value of this projection or the result of the given function on the opposing projection's
     * value.
     */
    public A on(final F<B, A> f) {
      return isLeft() ? value() : f.f(e.right().value());
    }

    /**
     * Execute a side-effect on this projection's value if it has one.
     *
     * @param f The side-effect to execute.
     * @return The unit value.
     */
    public Unit foreach(final F<A, Unit> f) {
      if(isLeft())
        f.f(value());

      return unit();
    }

    /**
     * Execute a side-effect on this projection's value if it has one.
     *
     * @param f The side-effect to execute.
     */
    public void foreach(final Effect<A> f) {
      if(isLeft())
        f.e(value());
    }
    /**
     * Map the given function across this projection's value if it has one.
     *
     * @param f The function to map across this projection.
     * @return A new either value after mapping.
     */
    public <X> Either<X, B> map(final F<A, X> f) {
      return isLeft() ? new Left<X, B>(f.f(value())) : new Right<X, B>(e.right().value());
    }

    /**
     * Binds the given function across this projection's value if it has one.
     *
     * @param f The function to bind across this projection.
     * @return A new either value after binding.
     */
    public <X> Either<X, B> bind(final F<A, Either<X, B>> f) {
      return isLeft() ? f.f(value()) : new Right<X, B>(e.right().value());
    }

    /**
     * Returns <code>None</code> if this projection has no value or if the given predicate
     * <code>p</code> does not hold for the value, otherwise, returns a left in <code>Some</code>.
     *
     * @param f The predicate function to test on this projection's value.
     * @return <code>None</code> if this projection has no value or if the given predicate
     * <code>p</code> does not hold for the value, otherwise, returns a left in <code>Some</code>.
     */
    public <X> Option<Either<A, X>> filter(final F<A, Boolean> f) {
      return isLeft() ?
          f.f(value()) ?
              Option.<Either<A, X>>some(new Left<A, X>(value())) :
              Option.<Either<A, X>>none() :
          Option.<Either<A, X>>none();
    }

    /**
     * Function application on this projection's value.
     *
     * @param e The either of the function to apply on this projection's value.
     * @return The result of function application within either.
     */
    public <X> Either<X, B> apply(final Either<F<A, X>, B> e) {
      return e.left().bind(new F<F<A, X>, Either<X, B>>() {
        public Either<X, B> f(final F<A, X> f) {
          return map(f);
        }
      });
    }

    /**
     * Returns <code>true</code> if no value or returns the result of the application of the given
     * function to the value.
     *
     * @param f The predicate function to test on this projection's value.
     * @return <code>true</code> if no value or returns the result of the application of the given
     * function to the value.
     */
    public boolean forall(final F<A, Boolean> f) {
      return !isLeft() || f.f(value());
    }

    /**
     * Returns <code>false</code> if no value or returns the result of the application of the given
     * function to the value.
     *
     * @param f The predicate function to test on this projection's value.
     * @return <code>false</code> if no value or returns the result of the application of the given
     * function to the value.
     */
    public boolean exists(final F<A, Boolean> f) {
      return isLeft() && f.f(value());
    }

    /**
     * Returns a single element list if this projection has a value, otherwise an empty list.
     *
     * @return A single element list if this projection has a value, otherwise an empty list.
     */
    public List<A> toList() {
      return isLeft() ? single(value()) : List.<A>nil();
    }

    /**
     * Returns this projection's value in <code>Some</code> if it exists, otherwise
     * <code>None</code>.
     *
     * @return This projection's value in <code>Some</code> if it exists, otherwise
     * <code>None</code>.
     */
    public Option<A> toOption() {
      return isLeft() ? some(value()) : Option.<A>none();
    }

    /**
     * Returns a single element array if this projection has a value, otherwise an empty array.
     *
     * @return A single element array if this projection has a value, otherwise an empty array.
     */
    @SuppressWarnings({"unchecked"})
    public Array<A> toArray() {
      return isLeft() ? array(value()) : Array.<A>empty();
    }

    /**
     * Returns a single element stream if this projection has a value, otherwise an empty stream.
     *
     * @return A single element stream if this projection has a value, otherwise an empty stream.
     */
    public Stream<A> toStream() {
      return isLeft() ? Stream.single(value()) : Stream.<A>nil();
    }
  }

  /**
   * A right projection of an either value.
   */
  public final class RightProjection<A, B> {
    private final Either<A, B> e;

    private RightProjection(final Either<A, B> e) {
      this.e = e;
    }

    /**
     * The either value underlying this projection.
     *
     * @return The either value underlying this projection.
     */
    public Either<A, B> either() {
      return e;
    }

     /**
     * Returns the value of this projection or fails with the given error message.
     *
     * @param err The error message to fail with.
     * @return The value of this projection
     */
    public B valueE(final P1<String> err) {
      if(e.isRight())
        //noinspection CastToConcreteClass
        return ((Right<A, B>)e).b;
      else
        throw error(err._1());
    }

    /**
     * The value of this projection or fails with a specialised error message.
     *
     * @return The value of this projection.
     */
    public B value() {
      return valueE(p("right.value on Left"));
    }

    /**
     * The value of this projection or the given argument.
     *
     * @param b The value to return if this projection has no value.
     * @return The value of this projection or the given argument.
     */
    public B orValue(final P1<B> b) {
      return isRight() ? value() : b._1();
    }

    /**
     * The value of this projection or the result of the given function on the opposing projection's
     * value.
     *
     * @param f The function to execute if this projection has no value.
     * @return The value of this projection or the result of the given function on the opposing projection's
     * value.
     */
    public B on(final F<A, B> f) {
      return isRight() ? value() : f.f(e.left().value());
    }

    /**
     * Execute a side-effect on this projection's value if it has one.
     *
     * @param f The side-effect to execute.
     * @return The unit value.
     */
    public Unit foreach(final F<B, Unit> f) {
      if(isRight())
        f.f(value());

      return unit();
    }

    /**
     * Execute a side-effect on this projection's value if it has one.
     *
     * @param f The side-effect to execute.
     */
    public void foreach(final Effect<B> f) {
      if(isRight())
        f.e(value());
    }

    /**
     * Map the given function across this projection's value if it has one.
     *
     * @param f The function to map across this projection.
     * @return A new either value after mapping.
     */
    public <X> Either<A, X> map(final F<B, X> f) {
      return isRight() ? new Right<A, X>(f.f(value())) : new Left<A, X>(e.left().value());
    }

    /**
     * Binds the given function across this projection's value if it has one.
     *
     * @param f The function to bind across this projection.
     * @return A new either value after binding.
     */
    public <X> Either<A, X> bind(final F<B, Either<A, X>> f) {
      return isRight() ? f.f(value()) : new Left<A, X>(e.left().value());
    }

    /**
     * Returns <code>None</code> if this projection has no value or if the given predicate
     * <code>p</code> does not hold for the value, otherwise, returns a left in <code>Some</code>.
     *
     * @param f The predicate function to test on this projection's value.
     * @return <code>None</code> if this projection has no value or if the given predicate
     * <code>p</code> does not hold for the value, otherwise, returns a left in <code>Some</code>.
     */
    public <X> Option<Either<X, B>> filter(final F<B, Boolean> f) {
      return isRight() ?
          f.f(value()) ?
              Option.<Either<X, B>>some(new Right<X, B>(value())) :
              Option.<Either<X, B>>none() :
          Option.<Either<X, B>>none();
    }

    /**
     * Function application on this projection's value.
     *
     * @param e The either of the function to apply on this projection's value.
     * @return The result of function application within either.
     */
    public <X> Either<A, X> apply(final Either<A, F<B, X>> e) {
      return e.right().bind(new F<F<B, X>, Either<A, X>>() {
        public Either<A, X> f(final F<B, X> f) {
          return map(f);
        }
      });
    }

    /**
     * Returns <code>true</code> if no value or returns the result of the application of the given
     * function to the value.
     *
     * @param f The predicate function to test on this projection's value.
     * @return <code>true</code> if no value or returns the result of the application of the given
     * function to the value.
     */
    public boolean forall(final F<B, Boolean> f) {
      return !isRight() || f.f(value());
    }

    /**
     * Returns <code>false</code> if no value or returns the result of the application of the given
     * function to the value.
     *
     * @param f The predicate function to test on this projection's value.
     * @return <code>false</code> if no value or returns the result of the application of the given
     * function to the value.
     */
    public boolean exists(final F<B, Boolean> f) {
      return isRight() && f.f(value());
    }
    
    /**
     * Returns a single element list if this projection has a value, otherwise an empty list.
     *
     * @return A single element list if this projection has a value, otherwise an empty list.
     */
    public List<B> toList() {
      return isRight() ? single(value()) : List.<B>nil();
    }

    /**
     * Returns this projection's value in <code>Some</code> if it exists, otherwise
     * <code>None</code>.
     *
     * @return This projection's value in <code>Some</code> if it exists, otherwise
     * <code>None</code>.
     */
    public Option<B> toOption() {
      return isRight() ? some(value()) : Option.<B>none();
    }

    /**
     * Returns a single element array if this projection has a value, otherwise an empty array.
     *
     * @return A single element array if this projection has a value, otherwise an empty array.
     */
    @SuppressWarnings({"unchecked"})
    public Array<B> toArray() {
      return isRight() ? array(value()) : Array.<B>empty();
    }

    /**
     * Returns a single element stream if this projection has a value, otherwise an empty stream.
     *
     * @return A single element stream if this projection has a value, otherwise an empty stream.
     */
    public Stream<B> toStream() {
      return isRight() ? Stream.single(value()) : Stream.<B>nil();
    }
  }

  /**
   * Construct a left value of either.
   *
   * @param a The value underlying the either.
   * @return A left value of either.
   */
  public static <A, B> Either<A, B> left(final A a) {
    return new Left<A, B>(a);
  }

  /**
   * A function that constructs a left value of either.
   *
   * @return A function that constructs a left value of either.
   */
  public static <A, B> F<A, Either<A, B>> left_() {
    return new F<A, Either<A, B>>() {
      public Either<A, B> f(final A a) {
        return left(a);
      }
    };
  }

  /**
   * A function that constructs a right value of either.
   *
   * @return A function that constructs a right value of either.
   */
  public static <A, B> F<B, Either<A, B>> right_() {
    return new F<B, Either<A, B>>() {
      public Either<A, B> f(final B b) {
        return right(b);
      }
    };
  }

  /**
   * Construct a right value of either.
   *
   * @param b The value underlying the either.
   * @return A right value of either.
   */
  public static <A, B> Either<A, B> right(final B b) {
    return new Right<A, B>(b);
  }

  /**
   * Joins an either through left.
   *
   * @param e The either of either to join.
   * @return An either after joining.
   */
  public static <A, B> Either<A, B> joinLeft(final Either<Either<A, B>, B> e) {
    final F<Either<A, B>, Either<A, B>> id = identity();
    return e.left().bind(id);
  }

  /**
   * Joins an either through right.
   *
   * @param e The either of either to join.
   * @return An either after joining.
   */
  public static <A, B> Either<A, B> joinRight(final Either<A, Either<A, B>> e) {
    final F<Either<A, B>, Either<A, B>> id = identity();
    return e.right().bind(id);
  }

  /**
   * Takes an <code>Either</code> to its contained value within left or right.
   *
   * @param e The either to reduce.
   * @return An <code>Either</code> to its contained value within left or right.
   */
  public static <A> A reduce(final Either<A, A> e) {
    return e.isLeft() ? e.left().value() : e.right().value();
  }

  /**
   * If the condition satisfies, return the given A in left, otherwise, return the given B in right.
   *
   * @param c The condition to test.
   * @param right The right value to use if the condition satisfies.
   * @param left The left value to use if the condition does not satisfy.
   * @return A constructed either based on the given condition.
   */
  public static <A, B> Either<A, B> iif(final boolean c, final P1<B> right, final P1<A> left) {
    return c ? new Right<A, B>(right._1()) : new Left<A, B>(left._1());
  }

  /**
   * Returns all the left values in the given list.
   *
   * @param es The list of possible left values.
   * @return All the left values in the given list.
   */
  public static <A> List<A> lefts(final List<Either<A, ?>> es) {
    return es.foldRight(new F<Either<A, ?>, F<List<A>, List<A>>>() {
      public F<List<A>, List<A>> f(final Either<A, ?> e) {
        return new F<List<A>, List<A>>() {
          public List<A> f(final List<A> as) {
            return e.isLeft() ? as.cons(e.left().value()) : as;
          }
        };
      }
    }, List.<A>nil());
  }

  /**
   * Returns all the right values in the given list.
   *
   * @param es The list of possible right values.
   * @return All the right values in the given list.
   */
  public static <B> List<B> rights(final List<Either<?, B>> es) {
    return es.foldRight(new F<Either<?, B>, F<List<B>, List<B>>>() {
      public F<List<B>, List<B>> f(final Either<?, B> e) {
        return new F<List<B>, List<B>>() {
          public List<B> f(final List<B> bs) {
            return e.isRight() ? bs.cons(e.right().value()) : bs;
          }
        };
      }
    }, List.<B>nil());
  }
}

