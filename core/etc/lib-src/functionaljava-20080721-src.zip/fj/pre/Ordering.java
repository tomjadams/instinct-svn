package fj.pre;

/**
 * The comparison of two instances of a type may have one of three orderings; less than, equal or
 * greater than.
 *
 * @version ${build.number}<br>
 *          <ul>
 *          <li>$LastChangedRevision: 10116 $</li>
 *          <li>$LastChangedDate: 2008-05-01 09:49:55 +1000 (Thu, 01 May 2008) $</li>
 *          </ul>
 */
public enum Ordering {
  /**
   * Less than.
   */
  LT,

  /**
   * Equal.
   */
  EQ,

  /**
   * Greater than. 
   */
  GT
}
