package fj;

/**
 * The unit type which has only one value.
 *
 * @version ${build.number}<br>
 *          <ul>
 *          <li>$LastChangedRevision: 9622 $</li>
 *          <li>$LastChangedDate: 2008-04-17 08:40:43 +1000 (Thu, 17 Apr 2008) $</li>
 *          </ul>
 */
public final class Unit {
  private static final Unit u = new Unit();

  private Unit() {

  }

  /**
   * The only value of the unit type.
   *
   * @return The only value of the unit type.
   */
  public static Unit unit() {
    return u;
  }
}
