package fj.control;

import fj.F;
import fj.Function;
import fj.P;
import fj.P1;
import fj.data.Either;
import fj.data.Java;
import fj.data.List;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

/**
 * Functional-style parallel processing for Java.
 * Author: Runar
 * Date: May 21, 2008
 * Time: 9:54:00 PM
 */
public final class Parallel {
  private Parallel() {
    throw new UnsupportedOperationException();
  }

  /**
   * A Strategy is a method of turning a product-1 into a Future.
   * It can be implemented by a naive thread invocation, a work queue, or some other mechanism.
   */
  public static interface Strategy<A> extends F<P1<A>, Future<A>> {
  }

  /**
   * Waits for every Future in a list to obtain a value, and collects those values in a list.
   *
   * @param xs The list of Futures from which to get values.
   * @return A list of values extracted from the Futures in the argument list.
   */
  private static <A> List<Either<InterruptedException, Either<ExecutionException, A>>>
  mergeAll(final List<Future<A>> xs) {
    return xs.map(new F<Future<A>, Either<InterruptedException, Either<ExecutionException, A>>>() {
      public Either<InterruptedException, Either<ExecutionException, A>> f(final Future<A> x) {
        Either<InterruptedException, Either<ExecutionException, A>> r;
        try {
          r = Either.right(Either.<ExecutionException, A>right(x.get()));
        } catch (InterruptedException e) {
          Thread.currentThread().interrupt();
          r = Either.left(e);
        } catch (ExecutionException e) {
          r = Either.right(Either.<ExecutionException, A>left(e));
        }
        return r;
      }
    });
  }

  /**
   * Evaluates a list of 1-products in parallel.
   *
   * @param s  A parallelization strategy for turning elements of the second argument into Futures.
   * @param ps A list to evaluate in parallel.
   * @return A list of the values of the 1-products in the second argument.
   */
  public static <A> List<Either<InterruptedException, Either<ExecutionException, A>>>
  parList(final Strategy<A> s, final List<P1<A>> ps) {
    return mergeAll(ps.map(s));
  }

  /**
   * Lifts a function to a parallel function on lists.
   *
   * @param s A parallelization strategy for turning arguments, to the given function, into Futures.
   * @param f A function to transform into a parallel function on lists.
   * @return The function transformed into a parallel function on lists.
   */
  public static <A, B> F<List<A>, List<Either<InterruptedException, Either<ExecutionException, B>>>>
  parMap(final Strategy<B> s, final F<A, B> f) {
    return new F<List<A>, List<Either<InterruptedException, Either<ExecutionException, B>>>>() {
      public List<Either<InterruptedException, Either<ExecutionException, B>>> f(final List<A> as) {
        return parList(s, as.map(Function.compose(P.<B>p1(), f)));
      }
    };
  }

  /**
   * @return A simple strategy that creates, and discards, a new thread for every evaluation.
   */
  public static <A> Strategy<A> naiveThreadStrategy() {
    return new Strategy<A>() {
      public Future<A> f(final P1<A> p) {
        final FutureTask<A> t = new FutureTask<A>(Java.<A>P1_Callable().f(p));
        new Thread(t).start();
        return t;
      }
    };
  }

}
