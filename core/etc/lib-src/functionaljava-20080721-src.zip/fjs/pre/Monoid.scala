package fjs.pre

import F._

object Monoid {
  implicit def monoid[A](sum: A => A => A, zero: A): fj.pre.Monoid[A] =
    fj.pre.Monoid.monoid(sum andThen (g => g: fj.F[A, A]), zero)

  implicit val intPlusMonoid = fj.pre.Monoid.intPlusMonoid
}
